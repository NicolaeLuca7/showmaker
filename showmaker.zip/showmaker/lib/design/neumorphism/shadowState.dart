enum ShadowState { In, Out }
