import 'dart:core';

import 'package:flutter/material.dart';
import 'package:showmaker/design/neumorphism/shadowState.dart';

// ignore: must_be_immutable
class NeumorphicIconButton extends StatelessWidget {
  Icon icon;
  double width;
  double height;
  BorderRadius borderRadius;
  double borderWidth = 0;
  Offset shadowOffset = Offset.zero;
  double blurRadius = 0.0;
  Color color = Colors.transparent;
  Color shadowColor = Colors.transparent;
  Color splashColor = Colors.transparent;
  Color borderColor = Colors.transparent;
  LinearGradient gradient;
  LinearGradient borderGradient;
  void Function()? onPressed;
  bool activated;

  NeumorphicIconButton(
      {required this.icon,
      required this.width,
      required this.height,
      required this.borderRadius,
      required this.activated,
      this.borderWidth = 0,
      this.shadowOffset = Offset.zero,
      this.blurRadius = 0.0,
      this.color = Colors.transparent,
      this.shadowColor = Colors.transparent,
      this.splashColor = Colors.transparent,
      this.borderColor = Colors.transparent,
      this.gradient = const LinearGradient(
          colors: [Colors.transparent, Colors.transparent]),
      this.borderGradient = const LinearGradient(
          colors: [Colors.transparent, Colors.transparent]),
      this.onPressed});

  @override
  Widget build(BuildContext context) {
    ShadowState shadowState = ShadowState.Out;
    return Scaffold(
        backgroundColor: Colors.transparent,
        body: Center(child: StatefulBuilder(builder: (context, state) {
          //

          return AnimatedContainer(
              onEnd: () {
                if (shadowState.name == 'Out') return;

                shadowState = ShadowState.Out;
                state(() {});
              },
              duration: Duration(milliseconds: 150),
              height: height,
              width: width,
              decoration: BoxDecoration(
                  color: color,
                  gradient: gradient,
                  border: Border.all(color: borderColor, width: borderWidth),
                  borderRadius: borderRadius,
                  boxShadow: [
                    BoxShadow(
                        color: shadowColor,
                        blurRadius:
                            !(shadowState.name == 'In') ? blurRadius : 0.1,
                        offset: shadowOffset,
                        blurStyle: BlurStyle.outer)
                  ]),
              child: Material(
                color: color,
                borderRadius: borderRadius,
                child: InkWell(
                    borderRadius: borderRadius,
                    splashColor: splashColor,
                    onTap: () {
                      if (!activated) return;
                      shadowState = (shadowState.name == 'Out'
                          ? ShadowState.In
                          : ShadowState.Out);
                      state(() {});
                      if (onPressed != null) onPressed!();
                    },
                    child: Center(child: icon)),
              ));
        })));
  }
}
