class MyMap<Type> {
  Type value;
  MyMap(this.value);
}
