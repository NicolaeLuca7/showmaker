class MyInt {
  int value;
  MyInt(this.value);
}
