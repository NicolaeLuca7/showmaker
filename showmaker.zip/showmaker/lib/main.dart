import 'package:dart_openai/dart_openai.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'design/appThemes.dart';
import 'database/connection/connectScreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load();
  await Firebase.initializeApp(
    options: FirebaseOptions(
        apiKey: dotenv.env["FIRE_apiKey"]!,
        authDomain: dotenv.env["FIRE_authDomain"]!,
        projectId: dotenv.env["FIRE_projectId"]!,
        storageBucket: dotenv.env["FIRE_storageBucket"]!,
        messagingSenderId: dotenv.env["FIRE_messagingSenderId"]!,
        appId: dotenv.env["FIRE_appId"]!,
        measurementId: dotenv.env["FIRE_measurementId"]!),
  );

  await dotenv.load();
  OpenAI.apiKey = dotenv.env['OPEN_AI_API_KEY']!;

  /*SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);*/

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: baseTheme,
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return ConnectScreen();
  }
}
