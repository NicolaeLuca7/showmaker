import 'package:dart_openai/dart_openai.dart';

class Prompts {
  static Future<List<String>> getTitles(String subject, int slides) async {
    List<String> titles = [];

    String response = (await OpenAI.instance.chat.create(
      model: "gpt-3.5-turbo",
      messages: [
        OpenAIChatCompletionChoiceMessageModel(
          content: getTitlesPrompt(subject, slides),
          role: OpenAIChatMessageRole.user,
        ),
      ],
    ))
        .choices[0]
        .message
        .content;

    response = response.replaceAll('"', '');
    for (int i = 0; i <= slides; i++) {
      String number = i.toString() + '.';
      response = response.replaceAll(number, '');
    }
    titles = response.split('\n');
    return titles;
  }

  static String getTitlesPrompt(String subject, int slides) {
    String prompt =
        'Generate $slides slide titles for a powerpoint presentation about $subject.Have only the titles.';
    return prompt;
  }
}
