class Parameters {
  String title = '';
  List<String> slideTitle = [];
  List<Shapes> shapes = [];
  List<Colors> colors = [];
  Style style = Style.Creative;

  Parameters() {}
}

enum Style { Retro, Creative, Futuristic }

enum Shapes { Lines, Squares, Circles, Triangles }

enum Colors {
  Red,
  Blue,
  Black,
  White,
  Green,
  Purple,
  Pink,
  Yellow,
  Orange,
  Brown,
}
