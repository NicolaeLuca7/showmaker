import 'dart:math';

import 'package:flutter/material.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:showmaker/common/myInt.dart';
import 'package:showmaker/design/themeColors.dart';
import 'package:showmaker/screens/show/configure/configureScreen.dart';
import 'package:showmaker/screens/slide/prevShows.dart';
import '../../database/User/user.dart';

// ignore: must_be_immutable
class MainScreen extends StatefulWidget {
  User1 user1;
  MainScreen({required this.user1, super.key});

  @override
  State<MainScreen> createState() => _MainScreenState(user1: user1);
}

class _MainScreenState extends State<MainScreen> {
  User1 user1;
  _MainScreenState({required this.user1});

  double aheight = 0, awidth = 0;
  PageController pageController = PageController(viewportFraction: 0.9);
  MyInt currentPage = MyInt(0);

  bool createPressed = false;

  @override
  void initState() {
    pageController.addListener(() {
      int next = pageController.page!.round();

      if (currentPage != next) {
        setState(() {
          currentPage.value = next;
        });
      }
    });
    super.initState();
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: LayoutBuilder(builder: (context, constrains) {
        aheight = constrains.maxHeight;
        awidth = constrains.maxWidth;
        return Container(
            height: aheight,
            width: awidth,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [themeColors.lightBlack, themeColors.darkBlack],
                  transform: GradientRotation(pi / 4)),
            ),
            child: Center(
                child: Stack(children: [
              Container(
                height: aheight,
                width: awidth,
                child: Stack(children: [
                  Padding(
                    padding: EdgeInsets.only(top: 10, left: awidth - 10 - 60),
                    child: Container(
                      width: 60,
                      height: 60,
                      child: CircleAvatar(
                          radius: 30,
                          backgroundImage: NetworkImage(user1.pfpUrl)),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: aheight - awidth * 0.4, left: awidth * 0.12),
                    child: Container(
                      height: awidth * 0.7,
                      width: awidth * 0.8,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(awidth * 0.35),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: awidth * 0.3,
                                color: themeColors.lightOrange.withOpacity(0),
                                blurStyle: BlurStyle.normal)
                          ]),
                    ),
                  )
                ]),
              ),
              Container(
                child: Center(
                  child: Column(children: [
                    Spacer(),

                    //
                    Container(
                        height: aheight * 1 / 2.5,
                        width: awidth,
                        child: Builder(
                            builder: (context) => getPrevShows(currentPage,
                                pageController, aheight * 1 / 2.5, awidth))),
                    //

                    Spacer(),
                    Padding(
                        padding: EdgeInsets.only(bottom: 40),
                        child: Container(
                            height: 60,
                            width: 140,
                            decoration: BoxDecoration(
                              color: themeColors.accentBlack,
                              border: GradientBoxBorder(
                                gradient: LinearGradient(colors: [
                                  themeColors.lightOrange.withOpacity(0.8),
                                  themeColors.darkOrange.withOpacity(0.8)
                                ]),
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Material(
                              color: themeColors.accentBlack,
                              borderRadius: BorderRadius.circular(10),
                              child: InkWell(
                                  borderRadius: BorderRadius.circular(10),
                                  splashColor: Colors.white.withOpacity(0.2),
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: ((context) =>
                                                ConfigureScreen())));
                                  },
                                  child: Center(
                                      child: Row(
                                    children: [
                                      Spacer(),
                                      Text(
                                        "Create",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 30),
                                      ),
                                      Spacer(flex: 1),
                                      Icon(
                                        Icons.add,
                                        color: Colors.white,
                                      ),
                                      Spacer(flex: 2)
                                    ],
                                  ))),
                            )))
                    //SizedBox(height: 40)
                  ]),
                ),
              )
            ])));
      })),
    );
  }
}
