import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:showmaker/common/myInt.dart';
import 'package:showmaker/design/neumorphism/neumorphicIconButton.dart';
import 'package:showmaker/design/neumorphism/neumorphicTextButton.dart';
import 'package:showmaker/design/themeColors.dart';
import 'package:showmaker/prompting/prompts.dart';
import 'package:showmaker/prompting/parameters.dart' as par;

// ignore: must_be_immutable
class BackgroundPreferences extends StatefulWidget {
  MyInt screenIndex;
  par.Parameters parameters;
  StateSetter state;

  BackgroundPreferences(
      {required this.screenIndex,
      required this.parameters,
      required this.state,
      super.key});

  @override
  State<BackgroundPreferences> createState() => _BackgroundPreferencesState(
      screenIndex: screenIndex, parameters: parameters, state: state);
}

class _BackgroundPreferencesState extends State<BackgroundPreferences> {
  MyInt screenIndex;
  par.Parameters parameters;
  StateSetter state;

  _BackgroundPreferencesState(
      {required this.screenIndex,
      required this.parameters,
      required this.state});

  double aheight = 0;
  double awidth = 0;
  TextEditingController subjectController = TextEditingController();
  bool generated = false;
  int slideCount = 0;
  bool generateOn = true;
  bool loading = false;
  bool pageCompleted = false;

  List<TextEditingController> titleCnt = [];

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!loading) {
      if (subjectController.text.length == 0 || slideCount == 0)
        generateOn = false;
      else
        generateOn = true;
      if (titleCnt.length != 0 && slideCount > 0) pageCompleted = true;
    } else {
      pageCompleted = false;
    }

    aheight = MediaQuery.of(context).size.height;
    awidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SingleChildScrollView(
        physics: ClampingScrollPhysics(),
        child: SizedBox(
          height: aheight,
          width: awidth,
          child: Container(
            height: aheight,
            width: awidth,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [themeColors.lightBlack, themeColors.darkBlack],
                  transform: GradientRotation(pi / 4)),
            ),
            child: Center(
              child: Column(
                children: [
                  SizedBox(
                    height: 25,
                  ),
                  //
                  Container(
                      width: awidth,
                      height: 60,
                      child: Row(
                        children: [
                          SizedBox(width: aheight * 0.01),
                          SizedBox(
                              width: 40,
                              height: 40,
                              child: NeumorphicIconButton(
                                  activated: true,
                                  icon: Icon(
                                    Icons.arrow_back_ios_rounded,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                  width: 40,
                                  height: 40,
                                  color: Colors.transparent,
                                  shadowColor: themeColors.darkOrange,
                                  blurRadius: 7,
                                  borderRadius: BorderRadius.circular(20),
                                  splashColor: Colors.white.withOpacity(0.3),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  })),
                          Spacer(),
                          SizedBox(
                            width: 120,
                            height: 40,
                            child: NeumorphicTextButton(
                                activated: pageCompleted,
                                text: Text(
                                  'Next',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 24,
                                      fontWeight: FontWeight.w300),
                                ),
                                width: 120,
                                height: 40,
                                color: Colors.transparent,
                                shadowColor: themeColors.darkOrange,
                                blurRadius: 7,
                                borderRadius: BorderRadius.circular(10),
                                splashColor: Colors.white.withOpacity(0.3),
                                onPressed: () => nextSlide()),
                          ),
                          SizedBox(
                            width: 20,
                          )
                        ],
                      )),
                  //
                  //SizedBox(height: aheight * 0.03),
                  //
                  Container(
                    width: awidth,
                    height: 130,
                    child: Row(children: [
                      SizedBox(width: aheight * 0.01),
                      Text(
                        'Background \nSettings',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 45,
                            decoration: TextDecoration.underline,
                            decorationColor: Colors.white,
                            decorationThickness: 0.9),
                      )
                    ]),
                  ),
                  //
                  SizedBox(height: 15),
                  //
                  Container(
                      width: awidth,
                      height: aheight * 0.1,
                      child: Row(children: [
                        SizedBox(
                          width: awidth * 0.1,
                        ),
                        Container(
                          width: awidth * 0.5,
                          height: aheight * 0.1,
                          child: TextField(
                            readOnly: true,
                            onChanged: (t) {
                              generated = false;
                            },
                            maxLength: 100,
                            maxLines: 1,
                            controller: subjectController,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: aheight * 0.2 * 0.3 * 0.7,
                            ),
                            decoration: InputDecoration(
                              hintText: "Title",
                              hintStyle: TextStyle(
                                  color: Colors.white.withOpacity(0.5),
                                  fontSize: aheight * 0.2 * 0.3 * 0.7,
                                  fontWeight: FontWeight.w200),
                              contentPadding: EdgeInsets.all(0.0),
                              isDense: true,
                            ),
                          ),
                        ),
                        Spacer(),
                        IconButton(
                          icon: Icon(
                            Icons.edit,
                            color: Colors.white,
                          ),
                          onPressed: () => subjectDialog(),
                        ),
                        SizedBox(
                          width: awidth * 0.1,
                        ),
                      ])),
                  //
                  SizedBox(height: 15),
                  //
                  Container(
                    width: awidth,
                    height: 60,
                    child: Center(
                        child: Row(
                      children: [
                        Spacer(
                          flex: 2,
                        ),
                        Text(
                          "Slides:",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: aheight * 0.2 * 0.3 * 0.7,
                          ),
                        ),
                        Spacer(),
                        SizedBox(
                          width: awidth * 0.3,
                          height: aheight * 0.1,
                          child: CupertinoPicker(
                            itemExtent: aheight * 0.2 * 0.3 * 0.5,
                            onSelectedItemChanged: (val) {
                              setState(() {
                                slideCount = val;
                              });
                            },
                            scrollController:
                                FixedExtentScrollController(initialItem: 0),
                            children: [
                              for (int i = 0; i <= 10; i++)
                                Text(
                                  '$i',
                                  style: TextStyle(
                                    fontSize: aheight * 0.2 * 0.3 * 0.5,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        Spacer(
                          flex: 2,
                        ),
                      ],
                    )),
                  ),
                  //
                  Spacer(),
                  //
                  Container(
                    width: awidth * 0.8,
                    height: aheight * 0.08,
                    child: Center(
                      child: Text(
                        'Generated titles:',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: aheight * 0.2 * 0.3 * 0.7),
                      ),
                    ),
                  ),
                  //
                  SizedBox(height: 10),
                  //
                  Container(
                    width: awidth * 0.85,
                    height: 220,
                    decoration: BoxDecoration(
                      color: themeColors.accentBlack,
                      border: GradientBoxBorder(
                        gradient: LinearGradient(
                          colors: [
                            themeColors.lightOrange.withOpacity(0.8),
                            themeColors.darkOrange.withOpacity(0.8)
                          ],
                        ),
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: !loading
                          ? ListView(
                              children: [
                                for (int i = 0; i < titleCnt.length; i++)
                                  Container(
                                    padding: EdgeInsets.only(
                                        left: 10, right: 10, top: 0, bottom: 0),
                                    height: 50,
                                    child: TextField(
                                      maxLines: 1,
                                      controller: titleCnt[i],
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 30,
                                      ),
                                      decoration: InputDecoration(
                                        hintStyle: TextStyle(
                                            color:
                                                Colors.white.withOpacity(0.5),
                                            fontSize: 20,
                                            fontWeight: FontWeight.w200),
                                        contentPadding: EdgeInsets.all(0.0),
                                        isDense: true,
                                      ),
                                    ),
                                  ),
                              ],
                            )
                          : SizedBox(child: CircularProgressIndicator()),
                    ),
                  ),
                  //
                  SizedBox(height: 15),

                  //
                  SizedBox(
                    width: 120,
                    height: 60,
                    child: NeumorphicTextButton(
                        activated: generateOn,
                        text: Text(
                          'Generate',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.w300),
                        ),
                        width: 120,
                        height: 60,
                        color: Colors.transparent,
                        shadowColor: themeColors.darkOrange,
                        blurRadius: 7,
                        borderRadius: BorderRadius.circular(10),
                        splashColor: Colors.white.withOpacity(0.3),
                        onPressed: () async {
                          generateOn = false;
                          loading = true;
                          setState(() {});
                          //
                          List<String> list = await Prompts.getTitles(
                              subjectController.text, slideCount);

                          titleCnt.clear();
                          int i = 1;
                          for (String s in list) {
                            titleCnt
                                .add(TextEditingController(text: '${i}.' + s));
                            i++;
                          }
                          //
                          generateOn = true;
                          loading = false;
                          setState(() {});
                        }),
                  ), //
                  Spacer(),
                  //
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void subjectDialog() {
    TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          body: Container(
            height: aheight,
            width: awidth,
            color: Colors.transparent,
            child: Stack(
              children: [
                SizedBox(
                    height: aheight,
                    width: awidth,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      behavior: HitTestBehavior.opaque,
                    )),
                Center(
                  child: Container(
                    height: aheight * 0.25,
                    width: awidth * 0.8,
                    decoration: BoxDecoration(
                      color: themeColors.accentBlack,
                      border: GradientBoxBorder(
                        gradient: LinearGradient(
                          colors: [
                            themeColors.lightOrange.withOpacity(0.8),
                            themeColors.darkOrange.withOpacity(0.8)
                          ],
                        ),
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Column(
                        children: [
                          Text(
                            'Subject',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: aheight * 0.2 * 0.3 * 0.7),
                          ),
                          Container(
                            width: awidth * 0.5,
                            height: aheight * 0.08,
                            child: TextField(
                              onChanged: (t) {
                                generated = false;
                              },
                              maxLength: 100,
                              maxLines: 1,
                              controller: controller,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: aheight * 0.2 * 0.3 * 0.7,
                              ),
                              decoration: InputDecoration(
                                hintText: "Title",
                                hintStyle: TextStyle(
                                    color: Colors.white.withOpacity(0.5),
                                    fontSize: aheight * 0.2 * 0.3 * 0.7,
                                    fontWeight: FontWeight.w200),
                                contentPadding: EdgeInsets.all(0.0),
                                isDense: true,
                              ),
                            ),
                          ),
                          Container(
                            height: aheight * 0.1,
                            width: awidth * 0.8,
                            child: Row(
                              children: [
                                Spacer(),
                                TextButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStateColor.resolveWith(
                                                (states) =>
                                                    Colors.transparent)),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    child: Text(
                                      "Cancel",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: aheight * 0.2 * 0.3 * 0.5),
                                    )),
                                Spacer(flex: 2),
                                TextButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStateColor.resolveWith(
                                                (states) =>
                                                    Colors.transparent)),
                                    onPressed: () {
                                      subjectController.text = controller.text;
                                      Navigator.pop(context);
                                    },
                                    child: Text(
                                      "Confirm",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: aheight * 0.2 * 0.3 * 0.5),
                                    )),
                                Spacer(),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void nextSlide() {
    List<String> list = [];
    for (var cnt in titleCnt) {
      list.add(cnt.text);
    }
    parameters.title = subjectController.text;
    parameters.slideTitle = list;
    //parameters.value['']

    screenIndex.value++;
    state(() {});
  }
}
