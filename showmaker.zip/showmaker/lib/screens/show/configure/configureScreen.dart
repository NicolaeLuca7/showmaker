import 'package:flutter/material.dart';
import 'package:showmaker/common/myInt.dart';
import 'package:showmaker/prompting/parameters.dart' as par;
import 'package:showmaker/screens/show/configure/backgroundPreferences.dart';
import 'package:showmaker/screens/show/configure/subjectScreen.dart';

class ConfigureScreen extends StatefulWidget {
  const ConfigureScreen({super.key});

  @override
  State<ConfigureScreen> createState() => _ConfigureScreenState();
}

class _ConfigureScreenState extends State<ConfigureScreen> {
  MyInt screenIndex = MyInt(0);
  par.Parameters parameters = par
      .Parameters(); //MyMap<Map<String, dynamic>> parameters = MyMap<Map<String, dynamic>>({});
  List<Widget> screens = [];

  @override
  void initState() {
    screens = [
      SubjectScreen(
          screenIndex: screenIndex, parameters: parameters, state: setState),
      BackgroundPreferences(
          screenIndex: screenIndex, parameters: parameters, state: setState)
    ];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[screenIndex.value],
    );
  }
}
