import 'package:flutter/material.dart';
import 'package:showmaker/common/myInt.dart';
import 'package:showmaker/screens/slide/prevCard.dart';

Widget getPrevShows(MyInt currentPage, PageController pageController,
    double height, double width) {
  return PageView.builder(
    itemCount: 20,
    controller: pageController,
    itemBuilder: (BuildContext context, id) {
      bool active = id == currentPage.value;
      return getPrevCard(active, height, width);
    },
    scrollDirection: Axis.horizontal,
    physics: BouncingScrollPhysics(),
  );
}
