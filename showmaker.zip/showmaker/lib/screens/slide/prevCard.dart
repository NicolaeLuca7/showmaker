import 'package:flutter/material.dart';
import 'dart:ui';

import 'package:showmaker/design/themeColors.dart';

Widget getPrevCard(bool active, double height, double width) {
  Color color = !active ? Colors.black.withOpacity(0.3) : Colors.transparent;
  double textHeight = 40;
  String testUrl =
      "https://images.pexels.com/photos/674010/pexels-photo-674010.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";

  return Padding(
      padding: EdgeInsets.only(left: 10, right: 10),
      child: Container(
          height: height,
          width: width,
          child: Column(children: [
            Spacer(),
            SizedBox(
              height: 10,
            ),
            AnimatedContainer(
                height: height - (active ? 15 : 30) - textHeight,
                width: width,
                duration: Duration(milliseconds: 300),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage(testUrl),
                    ),
                    color: Colors.black,
                    boxShadow: [
                      BoxShadow(
                        color: themeColors.darkBlack.withOpacity(
                            active ? 1 : 0), // Colors.black.withOpacity(0.8),
                        blurRadius: 5,
                        offset: Offset(4.5, 4.5),
                      )
                    ]),
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 300),
                  height: height - (active ? 0 : 30) - textHeight,
                  width: width,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10), color: color),
                )),
            SizedBox(
                height: textHeight,
                child: Center(
                  child: Text("test"),
                )),
          ])));
}
