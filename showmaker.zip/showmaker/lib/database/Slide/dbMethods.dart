import 'dart:core';

import 'package:showmaker/database/Slide/slide.dart';

List<Map<String, dynamic>> slidesToDatabase(List<Slide> slides) {
  List<Map<String, dynamic>> list = [];
  for (Slide slide in slides) list.add(slide.toDatabase());
  return list;
}

List<Slide> slidesFromDatabase(List<Map<String, dynamic>> list) {
  List<Slide> slides = [];
  for (var data in list) slides.add(Slide.fromDatabase(data));
  return slides;
}
