import '../entity.dart';

class Slide implements Entity<Slide> {
  @override
  String? id;
  String userId;
  String showId;
  String title;
  String text;
  String finalImgUrl;
  String backgroundImgUrl;
  Map<String, dynamic> parameters;

  Slide(this.userId, this.showId, this.title, this.text, this.finalImgUrl,
      this.backgroundImgUrl, this.parameters);

  @override
  void setId(String id) {
    // TODO: implement setId
  }

  static Slide fromDatabase(Map<String, dynamic> data) => Slide(
      data['userId'],
      data['showId'],
      data['title'],
      data['text'],
      data['finalImgUrl'],
      data['backgroundImgUrl'],
      data['parameters']);

  @override
  Map<String, dynamic> toDatabase() => {
        'userId': userId,
        'showId': showId,
        'title': title,
        'text': text,
        'finalImgUrl': finalImgUrl,
        'backgroundImgUrl': backgroundImgUrl,
        'parameters': parameters,
      };
}
