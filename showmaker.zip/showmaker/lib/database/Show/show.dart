import 'package:showmaker/database/Slide/dbMethods.dart';
import 'package:showmaker/database/Slide/slide.dart';
import 'package:showmaker/database/entity.dart';

class Show implements Entity<Show> {
  @override
  String? id;
  String userId;
  String title;
  String coverImgUrl;
  String backgroundImgUrl;
  Map<String, dynamic> parameters;
  List<Slide> slides;

  Show(this.userId, this.title, this.coverImgUrl, this.backgroundImgUrl,
      this.parameters, this.slides);

  @override
  void setId(String id) {
    this.id = id;
  }

  static Show fromDatabase(Map<String, dynamic> data) => Show(
      data['userId'],
      data['title'],
      data['coverImgUrl'],
      data['backgroundImgUrl'],
      data['parameters'],
      slidesFromDatabase(data['slides']));

  @override
  Map<String, dynamic> toDatabase() => {
        'userId': userId,
        'title': title,
        'coverImgUrl': coverImgUrl,
        'backgroundImgUrl': backgroundImgUrl,
        'parameters': parameters,
        'slides': slidesToDatabase(slides),
      };
}
