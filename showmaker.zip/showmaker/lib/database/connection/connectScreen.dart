import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:showmaker/design/appThemes.dart';
import 'package:showmaker/design/themeColors.dart';

import '../User/dbMethods.dart';
import '../User/user.dart';
import 'authentication.dart';
import '../../screens/main_screen/mainScreen.dart';

class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  Authentication authentication = Authentication();
  bool googlePressed = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: blackColor,
        body: SafeArea(child: LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          constraints.maxHeight;

          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [themeColors.lightBlack, themeColors.darkBlack],
                  transform: GradientRotation(pi / 4)),
            ),
            child: Container(
              color: Colors.black.withOpacity(0),
              child: Center(
                  child: Column(children: [
                //Spacer(),
                Text(
                  "Welcome",
                  style: TextStyle(fontSize: 50, color: textColor),
                ),
                Spacer(
                  flex: 3,
                ),
                //

                Container(
                    width: 300,
                    height: 60,
                    decoration: BoxDecoration(
                      color: themeColors.accentBlack,
                      border: GradientBoxBorder(
                        gradient: LinearGradient(colors: [
                          themeColors.lightOrange.withOpacity(0.8),
                          themeColors.darkOrange.withOpacity(0.8)
                        ]),
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Material(
                      color: themeColors.accentBlack,
                      borderRadius: BorderRadius.circular(10),
                      child: InkWell(
                          borderRadius: BorderRadius.circular(10),
                          splashColor: Colors.white.withOpacity(0.2),
                          onTap: () => googleAction(),
                          child: Center(
                              child: Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              SvgPicture.asset(
                                'assets/googleIcon.svg',
                                height: 35,
                              ),
                              Spacer(),
                              Text(
                                "Google authentication",
                                style: TextStyle(
                                    fontSize: 22,
                                    color: baseTheme.textTheme.bodyLarge!.color,
                                    fontWeight: FontWeight.w400),
                              ),
                              Spacer(
                                flex: 2,
                              ),
                            ],
                          ))),
                    )),

                Spacer(),
              ])),
            ),
          );
        })));
  }

  void googleAction() async {
    if (googlePressed) return;
    googlePressed = true;

    User? user = await authentication.signInWithGoogle(context: context);
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        authentication.customSnackBar(
            content: 'Error signing in. Try again.',
            textColor: Colors.redAccent),
      );
      googlePressed = false;
    }

    User1? user1 = await getUser(user!.uid);
    if (user1 == null) {
      user1 = await createUser(user);
      if (user1 == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          authentication.customSnackBar(
              content: 'Error signing in. Try again.',
              textColor: Colors.redAccent),
        );
        googlePressed = false;
      }
    }
    if (user1 != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        authentication.customSnackBar(
            content: 'Successfully signed in.', textColor: Colors.greenAccent),
      );

      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => MainScreen(user1: user1!)));
    }
  }
}
