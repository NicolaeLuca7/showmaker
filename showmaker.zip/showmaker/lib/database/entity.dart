class Entity<T> {
  String? id;

  void setId(String id) {}

  Map<String, dynamic> toDatabase() => {};

  static fromDatabase(Map<String, dynamic> data) {}
}
