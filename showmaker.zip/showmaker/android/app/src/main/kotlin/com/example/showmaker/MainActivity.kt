package com.example.showmaker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
